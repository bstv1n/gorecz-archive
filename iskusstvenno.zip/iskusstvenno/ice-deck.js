/* gorecz — искусственно (archive 002)
   True Optical Ice Refraction Shader (samples #fog canvas in real-time with Voronoi ice cracks & chromatic aberration) */
(() => {
  if (!window.THREE) return;

  const container = document.getElementById('tt');
  const fogCanvas = document.getElementById('fog');
  if (!container || !fogCanvas) return;

  const cv = document.createElement('canvas');
  cv.className = 'tt-ice-canvas';
  cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:0;';
  container.prepend(cv);

  const renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, 0.1, 10);
  camera.position.z = 1;

  // Захватываем живой WebGL-канвас фона (#fog), чтобы лед РЕАЛЬНО преломлял воду и провода позади себя!
  const bgTexture = new THREE.CanvasTexture(fogCanvas);
  bgTexture.minFilter = THREE.LinearFilter;
  bgTexture.magFilter = THREE.LinearFilter;

  const VERT = `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `;

  // Фрагментный шейдер монолитной ледяной плиты с внутренними трещинами Вороного, инеем и оптической рефракцией
  const FRAG = `
    precision highp float;
    varying vec2 vUv;

    uniform sampler2D uBg;
    uniform vec4 uScreenRect; // x, y, w, h положения деки на экране
    uniform vec2 uWinRes;
    uniform float uTime;
    uniform float uBass;
    uniform float uDiscAngle;

    float hash(vec2 p) {
      vec3 p3 = fract(vec3(p.xyx) * 0.1031);
      p3 += dot(p3, p3.yzx + 33.33);
      return fract((p3.x + p3.y) * p3.z);
    }

    vec2 hash2(vec2 p) {
      vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
      p3 += dot(p3, p3.yzx + 33.33);
      return fract((p3.xx + p3.yz) * p3.zy);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
    }

    float fbm(vec2 p) {
      float v = 0.0, a = 0.5;
      mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
      for (int i = 0; i < 4; i++) { v += a * noise(p); p = m * p; a *= 0.5; }
      return v;
    }

    // Кристаллическая решетка Вороного для настоящих острых трещин внутри толщи льда
    vec3 voronoi(vec2 x) {
      vec2 n = floor(x), f = fract(x);
      vec2 mg, mr;
      float md = 8.0;
      for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
          vec2 g = vec2(float(i), float(j));
          vec2 o = hash2(n + g);
          vec2 r = g + o - f;
          float d = dot(r, r);
          if (d < md) { md = d; mr = r; mg = g; }
        }
      }
      md = 8.0;
      for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
          vec2 g = mg + vec2(float(i), float(j));
          vec2 o = hash2(n + g);
          vec2 r = g + o - f;
          if (dot(mr - r, mr - r) > 0.00001) {
            md = min(md, dot(0.5 * (mr + r), normalize(r - mr)));
          }
        }
      }
      return vec3(md, mr);
    }

    // SDF прямоугольника со скошенными колотыми углами
    float sdIceSlab(vec2 p, vec2 b, float r) {
      vec2 d = abs(p) - b + r;
      return min(max(d.x, d.y), 0.0) + length(max(d, 0.0)) - r;
    }

    void main() {
      // Координаты в пропорциях деки 1000 x 780
      vec2 p = (vUv - 0.5) * vec2(1.0, 0.78);

      // Острые кристаллические сколы по самой кромке ледяной плиты (высокочастотный граненый рельеф, НЕ синусоида!)
      vec3 edgeVoro = voronoi(p * 9.5 + 2.4);
      float edgeChip = (edgeVoro.x - 0.3) * 0.014 + (fbm(p * 18.0) - 0.5) * 0.009;
      float dSlab = sdIceSlab(p, vec2(0.478, 0.370), 0.022) + edgeChip;

      // Маска самого ледяного блока
      float alpha = smoothstep(0.003, -0.003, dSlab);
      if (alpha <= 0.001) discard;

      // Фаска (толщина скола) по краям ледяной глыбы
      float bevel = smoothstep(0.0, -0.045, dSlab);

      // Координаты вращающегося ледяного диска (центр 392, 390 -> в UV это x: -0.108, y: 0.0)
      vec2 discCenter = vec2(-0.108, 0.0);
      vec2 dp = p - discCenter;
      float rDisc = length(dp);
      float inPlatterWell = smoothstep(0.332, 0.320, rDisc);
      float inIceDisc = smoothstep(0.302, 0.296, rDisc);

      // Поворачиваем координаты внутри пластинки на угол вращения диска
      float ca = cos(uDiscAngle), sa = sin(uDiscAngle);
      vec2 rotDp = mat2(ca, -sa, sa, ca) * dp;

      // Многослойные трещины внутри глыбы льда и внутри вращающегося ледяного диска
      vec2 iceCoord = mix(p * 5.2, rotDp * 6.5 + 4.0, inIceDisc);
      vec3 v1 = voronoi(iceCoord + fbm(iceCoord * 2.0) * 0.28);
      vec3 v2 = voronoi(iceCoord * 2.3 + 7.1);

      // Тонкие острые внутренние трещины (эффект расколотого в глубине льда)
      float crack1 = smoothstep(0.045, 0.003, v1.x);
      float crack2 = smoothstep(0.035, 0.002, v2.x) * 0.55;
      float cracks = clamp(crack1 + crack2, 0.0, 1.0);

      // Микрорельеф замерзшей поверхности и инея (frost)
      float surfaceFrost = fbm(iceCoord * 6.0);
      float edgeFrost = (1.0 - bevel) * (0.5 + 0.5 * surfaceFrost);

      // Считаем физическую нормаль льда для преломления фона
      vec2 normal = v1.yz * 0.45 + v2.yz * 0.25;
      normal += normalize(p + 0.0001) * (1.0 - bevel) * 1.6; // Сильное преломление на гранях скола по периметру
      normal += normalize(dp + 0.0001) * smoothstep(0.015, 0.0, abs(rDisc - 0.300)) * 1.4; // Грань ледяного диска
      normal += (vec2(noise(iceCoord * 12.0), noise(iceCoord * 12.0 + 15.0)) - 0.5) * 0.35;

      // Переводим локальный UV деки в экранный UV фонового канваса #fog
      vec2 screenUv = vec2(
        (uScreenRect.x + vUv.x * uScreenRect.z) / uWinRes.x,
        1.0 - ((uScreenRect.y + (1.0 - vUv.y) * uScreenRect.w) / uWinRes.y)
      );

      // РЕАЛЬНАЯ ОПТИЧЕСКАЯ РЕФРАКЦИЯ ФОНА С ХРОМАТИЧЕСКОЙ АБЕРРАЦИЕЙ ЛЬДА
      vec2 refractOffset = normal * 0.038;
      vec3 bgR = texture2D(uBg, clamp(screenUv + refractOffset * 1.08, 0.001, 0.999)).rgb;
      vec3 bgG = texture2D(uBg, clamp(screenUv + refractOffset * 1.00, 0.001, 0.999)).rgb;
      vec3 bgB = texture2D(uBg, clamp(screenUv + refractOffset * 0.92, 0.001, 0.999)).rgb;
      vec3 refractedBg = vec3(bgR.r, bgG.g, bgB.b);

      // Глубокое поглощение света внутри толщи льда (Beer's Law)
      vec3 iceTint = vec3(0.07, 0.20, 0.32);
      vec3 col = mix(refractedBg * vec3(0.75, 0.92, 1.08), iceTint, 0.42 + surfaceFrost * 0.18);

      // Чаша под диском чуть темнее и глубже, а сам ледяной диск — чище и светлее
      col = mix(col, col * 0.72, inPlatterWell * (1.0 - inIceDisc));
      col += vec3(0.08, 0.22, 0.35) * inIceDisc * 0.45;

      // Внутреннее рассеивание света по трещинам (Subsurface Scattering на басу)
      vec3 crackColor = mix(vec3(0.65, 0.88, 1.0), vec3(0.92, 0.98, 1.0), crack1);
      col += crackColor * cracks * (0.28 + uBass * 0.45);

      // Иней и белесая изморозь по колотым краям глыбы
      col = mix(col, vec3(0.78, 0.93, 1.0), edgeFrost * 0.55);

      // Острый зеркальный блик (Specular) на гранях льда
      vec3 N3 = normalize(vec3(normal, 1.0));
      vec3 L1 = normalize(vec3(-0.6, 0.7, 0.8));
      vec3 L2 = normalize(vec3(0.7, -0.5, 0.6));
      float spec1 = pow(max(dot(N3, L1), 0.0), 24.0);
      float spec2 = pow(max(dot(N3, L2), 0.0), 16.0);
      col += vec3(0.90, 0.97, 1.0) * (spec1 * 0.65 + spec2 * 0.35);

      // Яркий ледяной кант на самом срезе глыбы и диска
      float rimLine = smoothstep(0.008, 0.0, abs(dSlab + 0.004));
      float discRim = smoothstep(0.005, 0.0, abs(rDisc - 0.299));
      col += vec3(0.85, 0.96, 1.0) * (rimLine * 0.7 + discRim * 0.55);

      gl_FragColor = vec4(col, alpha * 0.94);
    }
  `;

  const uniforms = {
    uBg: { value: bgTexture },
    uScreenRect: { value: new THREE.Vector4(0, 0, 1, 1) },
    uWinRes: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
    uTime: { value: 0 },
    uBass: { value: 0 },
    uDiscAngle: { value: 0 }
  };

  const mat = new THREE.ShaderMaterial({
    vertexShader: VERT,
    fragmentShader: FRAG,
    uniforms,
    transparent: true
  });

  const quad = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
  scene.add(quad);

  function resize() {
    const r = container.getBoundingClientRect();
    if (!r.width || !r.height) return;
    renderer.setSize(r.width, r.height, false);
    uniforms.uScreenRect.value.set(r.left, r.top, r.width, r.height);
    uniforms.uWinRes.value.set(window.innerWidth, window.innerHeight);
  }
  new ResizeObserver(resize).observe(container);
  window.addEventListener('resize', resize, { passive: true });
  window.addEventListener('scroll', () => {
    const r = container.getBoundingClientRect();
    uniforms.uScreenRect.value.set(r.left, r.top, r.width, r.height);
  }, { passive: true });
  resize();

  let last = performance.now(), angle = 0;
  function animate(now) {
    requestAnimationFrame(animate);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;

    const S = window.GS || {};
    if (S.playing) angle += dt * 1.15;

    // Обновляем текстуру с нижнего канваса #fog каждый кадр для честного преломления
    bgTexture.needsUpdate = true;
    const r = container.getBoundingClientRect();
    uniforms.uScreenRect.value.set(r.left, r.top, r.width, r.height);
    uniforms.uTime.value = now / 1000;
    uniforms.uBass.value = S.bass || 0;
    uniforms.uDiscAngle.value = angle;

    renderer.render(scene, camera);
  }
  requestAnimationFrame(animate);
})();